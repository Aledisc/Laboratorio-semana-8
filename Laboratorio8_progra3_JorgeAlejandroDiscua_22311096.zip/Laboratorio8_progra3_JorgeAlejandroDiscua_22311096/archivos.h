#ifndef ARCHIVOS_H
#define ARCHIVOS_H


#include <QFile>
#include <QTextStream>
#include <QTextEdit>
#include <QRegularExpression>
#include <QDir>
#include <QMessageBox>
#include <QDataStream>
#include <QSpinBox>
#include <QList>

class Archivos
{
public:
    Archivos();

    void crearArchivoEstudiantes(QTextEdit* texto);
    QString pathArchivoEstudiantes;
    void leerArchivoEstudiantes(QTextEdit* texto);
    void crearArchivoProducto(QTextEdit* datos);
    QString pathArchivoProducto;
    void leerArchivoProducto(QTextEdit* mostrar);
    void modificarStock(QSpinBox* codigo, QSpinBox* nuevoStock);
    void leerCSV(QTextEdit* texto);
    void reporteCSV();
};

#endif // ARCHIVOS_H
