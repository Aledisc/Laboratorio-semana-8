#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "archivos.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

Archivos arc;
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_4_clicked()
{
    exit(0);
}


void MainWindow::on_pushButton_5_clicked()
{
    arc.crearArchivoEstudiantes(ui->crearEstudiantes);
}


void MainWindow::on_pushButton_6_clicked()
{
    arc.leerArchivoEstudiantes(ui->leerEstudiantes);
}


void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void MainWindow::on_pushButton_7_clicked()
{
    arc.crearArchivoProducto(ui->crearProductos);
}


void MainWindow::on_pushButton_8_clicked()
{
    arc.leerArchivoProducto(ui->leerProductos);
}


void MainWindow::on_pushButton_9_clicked()
{
    arc.modificarStock(ui->sbCode,ui->sbStock);
}


void MainWindow::on_pushButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
    arc.leerCSV(ui->leerCSV);
}


void MainWindow::on_pushButton_10_clicked()
{
    arc.reporteCSV();
}

