#include "archivos.h"


Archivos::Archivos() {
    QString pathCSV = QDir::homePath() + "/Desktop/clasificacionesCSV.csv";

    QFile archivoCSV(pathCSV);
    if (!archivoCSV.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "No se pudo crear el archivo CSV.";
        return;
    }

    QTextStream out(&archivoCSV);

    out << "Nombre,Nota Primer Periodo,Nota Segundo Periodo,Nota Final,Estado\n";

    QStringList estudiantes = {"Juan Perez", "Maria Lopez", "Carlos Sanchez", "Ana Martinez",
                               "Luis Ramirez", "Pedro Torres", "Sofia Diaz", "Diego Fernandez",
                               "Lucia Morales", "Javier Herrera"};

    QList<QList<int>> notas = {
        {80, 90, 85}, {60, 75, 65}, {50, 40, 45}, {95, 88, 92},
        {70, 60, 65}, {55, 70, 60}, {90, 85, 88}, {45, 50, 48},
        {85, 78, 82}, {75, 68, 72}
    };

    for (int i = 0; i < estudiantes.size(); ++i) {
        QString nombre = estudiantes[i];
        int notaPrimerPeriodo = notas[i][0];
        int notaSegundoPeriodo = notas[i][1];
        int notaFinal = notas[i][2];
        QString estado = (notaFinal >= 60) ? "Aprobado" : "Reprobado";

        out << nombre << "," << notaPrimerPeriodo << "," << notaSegundoPeriodo << ","
            << notaFinal << "," << estado << "\n";
    }

    //cerrar el archivo
    archivoCSV.close();

    qDebug() << "Archivo CSV generado exitosamente en: " << pathCSV;

}

void Archivos::crearArchivoEstudiantes(QTextEdit *texto)
{
    QString contenido = texto->toPlainText();

    QRegularExpression formato("^\\w+\\s*-\\s*\\d+$");

    QStringList lineas = contenido.split("\n");

    QString escritorio = QDir::homePath() + "/Desktop/";
    pathArchivoEstudiantes = escritorio + "estudiantes_notas.txt";
    QString pathReporteEstudiantes = escritorio + "reporteEstudiantes.txt";

    QFile archivoEstudiantes(pathArchivoEstudiantes);
    if (!archivoEstudiantes.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(nullptr, "Error", "No se pudo crear el archivo de estudiantes en el escritorio");
        return;
    }

    QFile archivoReporte(pathReporteEstudiantes);
    if (!archivoReporte.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(nullptr, "Error", "No se pudo crear el archivo de reporte en el escritorio");
        return;
    }

    QTextStream outEstudiantes(&archivoEstudiantes);
    QTextStream outReporte(&archivoReporte);

    for (const QString& linea : lineas) {
        if (formato.match(linea).hasMatch()) {
            outEstudiantes << linea << "\n";  //escribir línea en estudiantes_notas.txt

            QStringList partes = linea.split("-");
            QString nombre = partes[0].trimmed();
            int nota = partes[1].trimmed().toInt();

            QString estado = (nota >= 60) ? "Aprobado" : "Reprobado";

            outReporte << nombre << " - " << estado << "\n";
        } else {
            QMessageBox::warning(nullptr, "Formato Incorrecto", "La línea '" + linea + "' no tiene el formato correcto.");
            archivoEstudiantes.close();
            archivoReporte.close();
            return;  // Si hay un error en el formato, se cancela la operación
        }
    }

    archivoEstudiantes.close();
    archivoReporte.close();

    QMessageBox::information(nullptr, "Éxito",
                             "Archivos generados correctamente en el escritorio.\n"
                             "Archivo de notas: " + pathArchivoEstudiantes + "\n"
                                                            "Archivo de reporte: " + pathReporteEstudiantes);

}

void Archivos::leerArchivoEstudiantes(QTextEdit *texto)
{
    QString pathReporteEstudiantes = QDir::homePath() + "/Desktop/reporteEstudiantes.txt";

    QFile archivoReporte(pathReporteEstudiantes);
    if (!archivoReporte.exists()) {
        QMessageBox::warning(nullptr, "Archivo no encontrado",
                             "No se encontró el archivo 'reporteEstudiantes.txt' en el escritorio.");
        return;
    }

    if (!archivoReporte.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(nullptr, "Error", "No se pudo abrir el archivo de reporte.");
        return;
    }

     QTextStream in(&archivoReporte);
    QString contenido = in.readAll();

    texto->setPlainText(contenido);

    archivoReporte.close();
}

void Archivos::crearArchivoProducto(QTextEdit *datos)
{
    QString contenido = datos->toPlainText();

    QRegularExpression formato("^\\d+\\s*-\\s*\\w+\\s*-\\s*\\d+(\\.\\d+)?\\s*-\\s*\\d+$");

    QStringList lineas = contenido.split("\n");

    QString escritorio = QDir::homePath() + "/Desktop/";
    pathArchivoProducto = escritorio + "productos.bin";

    QFile archivoProducto(pathArchivoProducto);
    if (!archivoProducto.open(QIODevice::WriteOnly)) {
        QMessageBox::warning(nullptr, "Error", "No se pudo crear el archivo binario en el escritorio");
        return;
    }

    QDataStream out(&archivoProducto);

    for (const QString& linea : lineas) {
        if (formato.match(linea).hasMatch()) {
            QStringList partes = linea.split("-");
            int codigo = partes[0].trimmed().toInt();
            QString nombre = partes[1].trimmed();
            double precio = partes[2].trimmed().toDouble();
            int cantidadStock = partes[3].trimmed().toInt();

            out << codigo << nombre << precio << cantidadStock;
        } else {
            QMessageBox::warning(nullptr, "Formato Incorrecto", "La línea '" + linea + "' no tiene el formato correcto.");
            archivoProducto.close();
            return;
        }
    }

    archivoProducto.close();

    QMessageBox::information(nullptr, "Éxito",
                             "Archivo binario generado correctamente en el escritorio.\n"
                             "Ruta: " + pathArchivoProducto);
}

void Archivos::leerArchivoProducto(QTextEdit *mostrar)
{
    QString pathArchivoProducto = QDir::homePath() + "/Desktop/productos.bin";

    QFile archivoProducto(pathArchivoProducto);
    if (!archivoProducto.exists()) {
        QMessageBox::warning(nullptr, "Archivo no encontrado",
                             "No se encontró el archivo 'productos.bin' en el escritorio.");
        return;
    }

    if (!archivoProducto.open(QIODevice::ReadOnly)) {
        QMessageBox::warning(nullptr, "Error", "No se pudo abrir el archivo binario.");
        return;
    }

    QDataStream in(&archivoProducto);

    mostrar->clear();

    while (!in.atEnd()) {
        int codigo;
        QString nombre;
        double precio;
        int cantidadStock;

        in >> codigo >> nombre >> precio >> cantidadStock;

        QString linea = QString::number(codigo) + " - " + nombre + " - "
                        + QString::number(precio, 'f', 2) + " - "
                        + QString::number(cantidadStock);
        mostrar->append(linea);
    }


    archivoProducto.close();

}

struct Producto {
    int codigo;
    QString nombre;
    double precio;
    int cantidadStock;
};

void Archivos::modificarStock(QSpinBox *codigo, QSpinBox *nuevoStock)
{
    QString pathArchivoProducto = QDir::homePath() + "/Desktop/productos.bin";

    QFile archivoProducto(pathArchivoProducto);
    if (!archivoProducto.exists()) {
        QMessageBox::warning(nullptr, "Archivo no encontrado",
                             "No se encontró el archivo 'productos.bin' en el escritorio.");
        return;
    }

    if (!archivoProducto.open(QIODevice::ReadWrite)) {
        QMessageBox::warning(nullptr, "Error", "No se pudo abrir el archivo binario.");
        return;
    }

    QDataStream inOut(&archivoProducto);

    bool encontrado = false;
    int codigoProducto = codigo->value();
    int nuevoStockProducto = nuevoStock->value();

    Producto producto;
    qint64 productSize = sizeof(producto.codigo) + sizeof(producto.nombre) + sizeof(producto.precio) + sizeof(producto.cantidadStock);

    while (!inOut.atEnd()) {
        qint64 posAntesDeLeer = archivoProducto.pos();

        inOut >> producto.codigo >> producto.nombre >> producto.precio >> producto.cantidadStock;

        if (producto.codigo == codigoProducto) {
            producto.cantidadStock = nuevoStockProducto;
            encontrado = true;

            archivoProducto.seek(posAntesDeLeer);

            inOut << producto.codigo << producto.nombre << producto.precio << producto.cantidadStock;

            break;
        }
    }

    if (!encontrado) {
        QMessageBox::warning(nullptr, "Error", "Producto con el código especificado no encontrado.");
    } else {
        QMessageBox::information(nullptr, "Éxito",
                                 "El stock del producto ha sido modificado correctamente.");
    }


    archivoProducto.close();
}

void Archivos::leerCSV(QTextEdit *texto)
{
    QString pathCSV = QDir::homePath() + "/Desktop/clasificacionesCSV.csv";

    QFile archivoCSV(pathCSV);
    if (!archivoCSV.exists()) {
        QMessageBox::warning(nullptr, "Archivo no encontrado",
                             "No se encontró el archivo 'clasificacionesCSV.csv' en el escritorio.");
        return;
    }


    if (!archivoCSV.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(nullptr, "Error", "No se pudo abrir el archivo CSV.");
        return;
    }

    QTextStream in(&archivoCSV);
    texto->clear();

    while (!in.atEnd()) {
        QString linea = in.readLine();
        texto->append(linea);
    }
    archivoCSV.close();

    QMessageBox::information(nullptr, "Lectura completa",
                             "El contenido del archivo CSV ha sido cargado exitosamente.");
}

void Archivos::reporteCSV()
{
    QString pathCSV = QDir::homePath() + "/Desktop/clasificacionesCSV.csv";

    QFile archivoCSV(pathCSV);
    if (!archivoCSV.exists()) {
        QMessageBox::warning(nullptr, "Archivo no encontrado",
                             "No se encontró el archivo 'clasificacionesCSV.csv' en el escritorio.");
        return;
    }

    if (!archivoCSV.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(nullptr, "Error", "No se pudo abrir el archivo CSV.");
        return;
    }

    QTextStream in(&archivoCSV);
    QString linea;

    int numeroAlumnos = 0;
    double sumaPrimerPeriodo = 0;
    double sumaSegundoPeriodo = 0;
    double sumaNotaFinal = 0;
    int aprobados = 0;
    int reprobados = 0;

    if (!in.atEnd()) {
        linea = in.readLine();
    }

    while (!in.atEnd()) {
        linea = in.readLine();
        QStringList partes = linea.split(',');

        if (partes.size() >= 5) {
            QString nombre = partes[0];
            double notaPrimerPeriodo = partes[1].toDouble();
            double notaSegundoPeriodo = partes[2].toDouble();
            double notaFinal = partes[3].toDouble();
            QString estado = partes[4];

            numeroAlumnos++;
            sumaPrimerPeriodo += notaPrimerPeriodo;
            sumaSegundoPeriodo += notaSegundoPeriodo;
            sumaNotaFinal += notaFinal;

            if (estado.trimmed() == "Aprobado") {
                aprobados++;
            } else if (estado.trimmed() == "Reprobado") {
                reprobados++;
            }
        }
    }

    double promedioPrimerPeriodo = (numeroAlumnos > 0) ? sumaPrimerPeriodo / numeroAlumnos : 0;
    double promedioSegundoPeriodo = (numeroAlumnos > 0) ? sumaSegundoPeriodo / numeroAlumnos : 0;
    double promedioNotaFinal = (numeroAlumnos > 0) ? sumaNotaFinal / numeroAlumnos : 0;

    archivoCSV.close();

    QString pathReporte = QDir::homePath() + "/Desktop/reporteCalificaciones.txt";
    QFile archivoReporte(pathReporte);

    if (!archivoReporte.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(nullptr, "Error", "No se pudo crear el archivo de reporte.");
        return;
    }

    QTextStream out(&archivoReporte);
    out << "Reporte de Calificaciones:\n";
    out << "Número de alumnos: " << numeroAlumnos << "\n";
    out << "Promedio Nota Primer Periodo: " << QString::number(promedioPrimerPeriodo, 'f', 2) << "\n";
    out << "Promedio Nota Segundo Periodo: " << QString::number(promedioSegundoPeriodo, 'f', 2) << "\n";
    out << "Promedio Nota Final: " << QString::number(promedioNotaFinal, 'f', 2) << "\n";
    out << "Cantidad de alumnos aprobados: " << aprobados << "\n";
    out << "Cantidad de alumnos reprobados: " << reprobados << "\n";

    archivoReporte.close();

    QMessageBox::information(nullptr, "Reporte Generado",
                             "El reporte ha sido generado exitosamente en: " + pathReporte);
}
